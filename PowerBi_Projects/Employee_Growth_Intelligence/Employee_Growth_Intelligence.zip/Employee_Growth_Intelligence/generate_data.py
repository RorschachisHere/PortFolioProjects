from __future__ import annotations

import os
import random
from dataclasses import dataclass
from datetime import date
from typing import List, Tuple

import numpy as np
import pandas as pd


# =========================
# CONFIG (DO NOT EDIT FIRST RUN)
# =========================
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

RAW_DIR = os.path.join(PROJECT_ROOT, "01_Raw_Data")
PROCESSED_DIR = os.path.join(PROJECT_ROOT, "02_Processed_Data")

OUT_RAW_XLSX = os.path.join(RAW_DIR, "Performance_Raw.xlsx")
OUT_FACT_CSV = os.path.join(PROCESSED_DIR, "FactPerformance_Clean.csv")
OUT_DIM_EMP_CSV = os.path.join(PROCESSED_DIR, "DimEmployee.csv")
OUT_DIM_DEPT_CSV = os.path.join(PROCESSED_DIR, "DimDepartment.csv")

SEED = 42
N_EMPLOYEES = 36

# 18 months: 2024-07-01 to 2025-12-01 (inclusive)
MONTH_START = pd.Timestamp("2024-07-01")
MONTH_END = pd.Timestamp("2025-12-01")
MONTHS = pd.date_range(MONTH_START, MONTH_END, freq="MS")

# Departments/Teams (fixed)
DEPT_TEAMS = {
    "Repairs": ["Hardware", "Micro-Soldering", "QC"],
    "Sales Support": ["Inbound", "Outbound"],
    "Technical Support": ["L1", "L2"],
    "Operations": ["Logistics", "Inventory"],
}

# Employee distribution (fixed)
DEPT_COUNTS = {
    "Repairs": 12,
    "Sales Support": 8,
    "Technical Support": 8,
    "Operations": 8,
}

# Performance types (probabilities must sum to 1.0)
PERF_TYPES = [
    ("High", 0.20),
    ("Stable", 0.50),
    ("Volatile", 0.20),
    ("Under", 0.10),
]

# Edge cases
N_NEW_HIRES = 3          # only last 6 months
N_TRANSFERS = 2          # department/team change mid-year
N_MISSING_MONTH = 4      # one random missing month
ZERO_MONTH_EMP = 1       # one employee has one month with 0 tickets (division-by-zero stress test)


# =========================
# HELPERS
# =========================
def ensure_dirs() -> None:
    os.makedirs(RAW_DIR, exist_ok=True)
    os.makedirs(PROCESSED_DIR, exist_ok=True)


def choose_weighted(items: List[Tuple[str, float]], rng: random.Random) -> str:
    r = rng.random()
    cumulative = 0.0
    for name, p in items:
        cumulative += p
        if r <= cumulative:
            return name
    return items[-1][0]


def month_index(ts: pd.Timestamp) -> int:
    return int((ts.year - MONTH_START.year) * 12 + (ts.month - MONTH_START.month))


@dataclass
class Employee:
    employee_id: str
    employee_name: str
    hire_date: pd.Timestamp
    dept: str
    team: str
    perf_type: str


def make_employee_name(i: int) -> str:
    # Neutral, consistent naming
    return f"Employee {i:02d}"


def build_employees(rng: random.Random) -> List[Employee]:
    employees: List[Employee] = []

    # Create dept allocations (exact counts)
    dept_pool: List[str] = []
    for d, c in DEPT_COUNTS.items():
        dept_pool.extend([d] * c)
    rng.shuffle(dept_pool)

    # Assign performance types by probability
    perf_assignments = [choose_weighted(PERF_TYPES, rng) for _ in range(N_EMPLOYEES)]

    # Hire dates:
    # - Most hired before/near start
    # - N_NEW_HIRES hired around last 6 months window
    # We'll first set all to older hires, then override new hires.
    older_hire_start = pd.Timestamp("2023-10-01")
    older_hire_end = pd.Timestamp("2024-06-15")

    for i in range(1, N_EMPLOYEES + 1):
        emp_id = f"EMP{i:03d}"
        name = make_employee_name(i)
        dept = dept_pool[i - 1]
        team = rng.choice(DEPT_TEAMS[dept])
        hire = pd.Timestamp(rng.choice(pd.date_range(older_hire_start, older_hire_end, freq="D")))
        employees.append(Employee(emp_id, name, hire, dept, team, perf_assignments[i - 1]))

    # Override NEW HIRES (last ~6 months of data)
    # last 6 months in our range: 2025-07-01 .. 2025-12-01
    new_hire_window_start = pd.Timestamp("2025-06-01")
    new_hire_window_end = pd.Timestamp("2025-10-15")
    new_hire_ids = rng.sample([e.employee_id for e in employees], k=N_NEW_HIRES)
    for e in employees:
        if e.employee_id in new_hire_ids:
            e.hire_date = pd.Timestamp(rng.choice(pd.date_range(new_hire_window_start, new_hire_window_end, freq="D")))

    return employees


def base_level_by_dept(dept: str) -> Tuple[int, int]:
    """
    Returns (base_min, base_max) monthly tickets resolved by department.
    Tuned to look realistic (not too round numbers).
    """
    if dept == "Repairs":
        return (60, 140)
    if dept == "Sales Support":
        return (80, 170)
    if dept == "Technical Support":
        return (90, 200)
    if dept == "Operations":
        return (50, 120)
    return (70, 150)


def generate_employee_series(emp: Employee, months: pd.DatetimeIndex, rng: np.random.Generator) -> np.ndarray:
    """
    Produces monthly tickets resolved with trend + noise + seasonality.
    """
    base_min, base_max = base_level_by_dept(emp.dept)
    base = rng.integers(base_min, base_max + 1)

    # Trend and volatility by performance type
    if emp.perf_type == "High":
        trend = rng.uniform(0.02, 0.06)       # +2% to +6% per month
        noise_sd = rng.uniform(6, 12)
    elif emp.perf_type == "Stable":
        trend = rng.uniform(-0.005, 0.015)    # -0.5% to +1.5% per month
        noise_sd = rng.uniform(5, 10)
    elif emp.perf_type == "Volatile":
        trend = rng.uniform(-0.01, 0.03)      # mixed
        noise_sd = rng.uniform(12, 25)        # bigger swings
    else:  # Under
        trend = rng.uniform(-0.03, 0.005)     # decline
        noise_sd = rng.uniform(6, 14)

    n = len(months)
    idx = np.arange(n)

    # Mild seasonality (e.g., end-year peaks, mid-year dips)
    season = 1.0 + 0.08 * np.sin(2 * np.pi * (idx / 12.0) + rng.uniform(0, 2*np.pi))

    # Exponential-ish trend
    trend_mult = (1.0 + trend) ** idx

    values = base * season * trend_mult + rng.normal(0, noise_sd, size=n)

        # Inject realistic spike months (ensures some 2x MoM events exist)
    # Volatile + High performers get occasional spikes
    spike_chance = 0.08 if emp.perf_type in ("Volatile", "High") else 0.03
    spikes = rng.random(n) < spike_chance
    spike_multiplier = rng.uniform(2.1, 3.0, size=n)
    values = np.where(spikes, values * spike_multiplier, values)

    # Clamp to non-negative and round to int
    values = np.clip(values, 0, None)
    values = np.rint(values).astype(int)

    return values


def apply_edge_cases(
    fact: pd.DataFrame,
    employees: List[Employee],
    py_rng: random.Random,
) -> pd.DataFrame:
    """
    Apply missing months, transfers, and one zero month.
    """
    fact = fact.copy()

    # 1) Missing month: remove one random month row for N_MISSING_MONTH employees
    missing_ids = py_rng.sample([e.employee_id for e in employees], k=N_MISSING_MONTH)
    for emp_id in missing_ids:
        emp_rows = fact[fact["EmployeeID"] == emp_id]
        # choose a month not the first month to avoid empty prev month everywhere
        candidate_months = emp_rows["Month"].sort_values().iloc[1:-1]
        if len(candidate_months) == 0:
            continue
        miss_month = py_rng.choice(list(candidate_months))
        fact = fact[~((fact["EmployeeID"] == emp_id) & (fact["Month"] == miss_month))]

    # 2) Transfers: department/team change mid-period for N_TRANSFERS employees
    transfer_ids = py_rng.sample([e.employee_id for e in employees if e.employee_id not in missing_ids], k=N_TRANSFERS)
    transfer_month = pd.Timestamp("2025-02-01")  # mid-ish
    for emp_id in transfer_ids:
        # pick a new dept different from current
        current_dept = fact.loc[fact["EmployeeID"] == emp_id, "Department"].mode().iloc[0]
        possible_depts = [d for d in DEPT_TEAMS.keys() if d != current_dept]
        new_dept = py_rng.choice(possible_depts)
        new_team = py_rng.choice(DEPT_TEAMS[new_dept])

        mask_after = (fact["EmployeeID"] == emp_id) & (fact["Month"] >= transfer_month)
        fact.loc[mask_after, "Department"] = new_dept
        fact.loc[mask_after, "Team"] = new_team

    # 3) Zero month stress-test for exactly one employee
    zero_emp_id = py_rng.choice([e.employee_id for e in employees])
    # choose a month where row exists
    emp_months = fact.loc[fact["EmployeeID"] == zero_emp_id, "Month"]
    if len(emp_months) > 0:
        zero_m = py_rng.choice(list(emp_months))
        fact.loc[(fact["EmployeeID"] == zero_emp_id) & (fact["Month"] == zero_m), "TicketsResolved"] = 0

    return fact


def build_fact_table(employees: List[Employee]) -> pd.DataFrame:
    np_rng = np.random.default_rng(SEED)
    py_rng = random.Random(SEED)

    rows = []
    for emp in employees:
        # Only include months on/after hire date month start
        emp_months = MONTHS[MONTHS >= pd.Timestamp(emp.hire_date.year, emp.hire_date.month, 1)]
        series = generate_employee_series(emp, emp_months, np_rng)

        for m, val in zip(emp_months, series):
            rows.append(
                {
                    "Month": m,
                    "EmployeeID": emp.employee_id,
                    "EmployeeName": emp.employee_name,  # included in raw extract for convenience
                    "Department": emp.dept,
                    "Team": emp.team,
                    "TicketsResolved": int(val),
                }
            )

    fact = pd.DataFrame(rows)

    # Apply edge cases to create realistic “mess”
    fact = apply_edge_cases(fact, employees, py_rng)

    # Re-sort
    fact = fact.sort_values(["EmployeeID", "Month"]).reset_index(drop=True)
    return fact


def build_dim_employee_from_fact(fact: pd.DataFrame, employees: List[Employee]) -> pd.DataFrame:
    # Use the employees list for authoritative hire date + performance type,
    # but allow dept/team to reflect "current" (latest month) assignment.
    emp_map = {e.employee_id: e for e in employees}

    latest = (
        fact.sort_values(["EmployeeID", "Month"])
            .groupby("EmployeeID")
            .tail(1)[["EmployeeID", "EmployeeName", "Department", "Team"]]
    )

    latest["HireDate"] = latest["EmployeeID"].map(lambda x: emp_map[x].hire_date)
    latest["PerformanceType"] = latest["EmployeeID"].map(lambda x: emp_map[x].perf_type)

    # Consistent column order
    dim_emp = latest[["EmployeeID", "EmployeeName", "Department", "Team", "HireDate", "PerformanceType"]].copy()
    dim_emp = dim_emp.sort_values("EmployeeID").reset_index(drop=True)
    return dim_emp


def build_dim_department() -> pd.DataFrame:
    return pd.DataFrame({"Department": list(DEPT_TEAMS.keys())}).sort_values("Department").reset_index(drop=True)


def validate_outputs(fact: pd.DataFrame, dim_emp: pd.DataFrame) -> None:
    # 1) Basic checks
    assert fact["EmployeeID"].nunique() == N_EMPLOYEES, "Employee count mismatch in fact table."
    assert fact["Month"].min() >= MONTH_START, "Fact contains months before configured start."
    assert fact["Month"].max() <= MONTH_END, "Fact contains months after configured end."
    assert fact["TicketsResolved"].dtype.kind in ("i", "u"), "TicketsResolved must be integer type."

    # 2) Ensure no negative values
    assert (fact["TicketsResolved"] >= 0).all(), "Negative TicketsResolved found."

    # 3) Ensure each employee has at least 1 row
    counts = fact.groupby("EmployeeID").size()
    assert (counts >= 1).all(), "An employee has zero rows in fact table."

    # 4) Ensure dim employee keys match fact keys
    assert set(dim_emp["EmployeeID"]) == set(fact["EmployeeID"].unique()), "DimEmployee keys do not match Fact keys."

    # 5) Warn-like checks (print)
    # Missing month existence:
    expected_rows_if_full = len(MONTHS) * N_EMPLOYEES
    actual_rows = len(fact)
    print(f"[INFO] Expected max rows (no hires/edge cases): {expected_rows_if_full}")
    print(f"[INFO] Actual fact rows (with hires/edge cases): {actual_rows}")
    print(f"[INFO] Employees: {fact['EmployeeID'].nunique()}, Months range: {fact['Month'].min().date()} -> {fact['Month'].max().date()}")

    # Division-by-zero stress: check at least one zero value exists
    zero_ct = int((fact["TicketsResolved"] == 0).sum())
    print(f"[INFO] Zero-month rows (TicketsResolved==0): {zero_ct} (should be >= 1)")

    # New hires (less than full 18 months)
    emp_month_counts = fact.groupby("EmployeeID")["Month"].nunique().sort_values()
    print("[INFO] Lowest 5 employee month counts (new hires/edge cases likely):")
    print(emp_month_counts.head(5).to_string())


def main() -> None:
    ensure_dirs()

    # Deterministic randomness
    random.seed(SEED)
    np.random.seed(SEED)

    py_rng = random.Random(SEED)
    employees = build_employees(py_rng)

    fact = build_fact_table(employees)
    dim_emp = build_dim_employee_from_fact(fact, employees)
    dim_dept = build_dim_department()

    # Save RAW Excel (what “the system exported”)
    # Keep it simple: one sheet named Performance
    raw_df = fact.rename(columns={"TicketsResolved": "MetricValue"})
    raw_df = raw_df[["Month", "EmployeeID", "EmployeeName", "Department", "Team", "MetricValue"]].copy()

    # Processed tables (clean layer)
    fact_clean = fact.copy()

    # Validate BEFORE writing
    validate_outputs(fact_clean, dim_emp)

    # Write outputs
    with pd.ExcelWriter(OUT_RAW_XLSX, engine="openpyxl") as writer:
        raw_df.to_excel(writer, sheet_name="Performance", index=False)

    fact_clean.to_csv(OUT_FACT_CSV, index=False)
    dim_emp.to_csv(OUT_DIM_EMP_CSV, index=False)
    dim_dept.to_csv(OUT_DIM_DEPT_CSV, index=False)

    print("\n[SUCCESS] Files created:")
    print(f" - {OUT_RAW_XLSX}")
    print(f" - {OUT_FACT_CSV}")
    print(f" - {OUT_DIM_EMP_CSV}")
    print(f" - {OUT_DIM_DEPT_CSV}")


if __name__ == "__main__":
    main()